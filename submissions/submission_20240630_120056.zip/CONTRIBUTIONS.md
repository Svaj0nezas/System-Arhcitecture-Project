# Contributions

Briefly describe how each team member has contributed to the project. It goes without saying that every team members should have a good grasp of all parts of the submission.

Nils worked on the arithmetic divider, parallel unit, and RV32M. Simon implemented everything in the RV32I folder.

# Use of AI tools

Did you use any AI tools for the project? If so, which tools did you use?
Yes, we used ChatGPT.

## Problem 1.2: Bonus

If you want to get the bonus points, please specify here which conditions you have identified and how you have implemented them in your circuit.
